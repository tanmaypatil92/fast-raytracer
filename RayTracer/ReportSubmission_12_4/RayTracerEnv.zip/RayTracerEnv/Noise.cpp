//
//  Noise.cpp
//  RayTracerEnv
//
//  Created by hima on 11/22/14.
//  Copyright (c) 2014 hima. All rights reserved.
//

#include "Noise.h"
