#ifndef _GZ_H_
#define _GZ_H_

#define SUCCESS 0
#define FAILURE 1

#if 0
#define XRES 480	
#define YRES 270
#else
#define XRES 1024	
#define YRES 576	
#endif
//#define	ARRAY(x,y,width) (x+(y*width))

#endif