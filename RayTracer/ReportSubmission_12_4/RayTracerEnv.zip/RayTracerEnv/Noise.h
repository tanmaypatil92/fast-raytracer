//
//  Noise.h
//  RayTracerEnv
//
//  Created by hima on 11/22/14.
//  Copyright (c) 2014 hima. All rights reserved.
//

#ifndef __RayTracerEnv__Noise__
#define __RayTracerEnv__Noise__

#include <stdio.h>

#endif /* defined(__RayTracerEnv__Noise__) */
