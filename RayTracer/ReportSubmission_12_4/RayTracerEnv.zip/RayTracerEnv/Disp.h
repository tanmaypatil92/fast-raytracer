#ifndef _DISP_H_
#define _DISP_H_

#include "Pixel.h"
//#define baseName    "/Users/enticer/developer/CS580/RayTracer/RayTracerEnv/RayTracerEnv/"
//#define outfile "render01.ppm"

int saveImage(Pixel *pixels, char *outFile);

#endif